import os

files = os.listdir('/srv/scratch/z5039045/MetaCHIP_demo/NorthSeaPy3_MetaCHIP_wd/NorthSeaPy3_p4_get_SCG_tree_wd')

for file in files:
    print(file)
